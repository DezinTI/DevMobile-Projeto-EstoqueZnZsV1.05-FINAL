package com.example.aula21.model.dto

data class UserDTO(
    val id: Int,
    val name: String,
    val username: String,
    val email: String
)
